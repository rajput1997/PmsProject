﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSProject.Models
{
    public class PMSDBContext:DbContext
    {
        public PMSDBContext(DbContextOptions<PMSDBContext> options) : base(options) { }

        public DbSet<Users> Users { get; set; }
        public DbSet<VerifyAccount> VerifyAccounts { get; set; }
        public DbSet<Employee> Departments { get; set; }
        public DbSet<Product> Employees { get; set; }

        
    }
}
